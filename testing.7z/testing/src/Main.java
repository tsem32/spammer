import java.awt.AWTException;
import java.awt.Image;
import java.awt.Robot;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import javax.swing.JFrame;

public class Main {

    public static void main(String[] args) throws AWTException {
        Image iconImage = new javax.swing.ImageIcon(SystemTray.class.getResource("/javax/swing/plaf/metal/icons/ocean/computer.gif")).getImage();
        TrayIcon trayIcon = new TrayIcon(iconImage, "SystemTray Example", null);
        MainPanel mainPanel = new MainPanel(new Spammer());

        // Handle double-click on the tray icon
        trayIcon.addActionListener(e -> {
            mainPanel.setVisible(!mainPanel.isVisible());
            if(mainPanel.isVisible()){
                mainPanel.requestFocus();
                mainPanel.setExtendedState(JFrame.NORMAL); // restore the frame if it was minimized

                mainPanel.toFront();
            }
        });
        try {
            SystemTray.getSystemTray().add(trayIcon);
        } catch (AWTException e) {
            e.printStackTrace();
        }

    }




}