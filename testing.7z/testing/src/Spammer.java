import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class Spammer  {
    private boolean running;
    private  Timer timer;
    private final Robot robot;

    public Spammer() throws AWTException {
         this.timer= new Timer();
         this.robot = new Robot();
    }

    public boolean isRunning() {
        return running;
    }
    public void setRunning(boolean running) {
        this.running = running;
    }

    public void stop(){
        this.timer.cancel();
        setRunning(false);
    }
    public void run() {
        this.timer= new Timer();
        setRunning(true);
        this.timer.schedule(new TimerTask() {
            @Override
            public void run() {
                robot.keyPress(KeyEvent.VK_0);
                robot.keyRelease(KeyEvent.VK_0);
                try {
                    TimeUnit.SECONDS.sleep(2);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                robot.keyPress(KeyEvent.VK_BACK_SPACE);
                robot.keyRelease(KeyEvent.VK_BACK_SPACE);
            }
        }, 0, 3000);
    }
}
