import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;

public class MainPanel extends JFrame {
    private JButton startButton;
    private JPanel centralPanel;
    private JTextArea textArea;
    private JLabel elapsedLabel;
    private final Spammer spammer;
    private  Timer elapsedTimer ;

    private long startTime;

    public MainPanel(Spammer spammer) {
        this.spammer = spammer;
        this.elapsedTimer  = new Timer();
        initDisplay();
        addStartButtonActionListener();

    }

    private void addStartButtonActionListener() {
        startButton.addActionListener(e -> {
            if (spammer.isRunning()) {
                spammer.stop();
                startButton.setText("Start");
                startButton.setBackground(new Color(30, 224, 128));
                elapsedTimer.cancel();
            } else {
                startTime = new Date().getTime();
                elapsedTimer = new Timer();
                elapsedTimer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        long diff = new Date().getTime() - startTime;//as given
                        long diffSeconds = diff / 1000 % 60;
                        long diffMinutes = diff / (60 * 1000) % 60;
                        long diffHours = diff / (60 * 60 * 1000);

                        elapsedLabel.setText("Hour: "+ diffHours+ " Min: "+diffMinutes+" Sec: "+diffSeconds);
                    }
                }, 0, 100);
                this.textArea.requestFocus();
                spammer.run();
                startButton.setText("Pause");
                startButton.setBackground(Color.RED);
            }
        });
    }

    private void initDisplay() {
        setContentPane(centralPanel);
        setTitle("Presence");
        setSize(250, 250);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowIconified(WindowEvent e) {
               setVisible(false);
            }
        });

        setLocationRelativeTo(null);
    }
}
